import requests
import datetime
import openai
import time
yourCity = input()
now = datetime.datetime.now()
def get_climate_data(city):
    url = f'http://api.openweathermap.org/data/2.5/climate/month?city={city}&start={date}&end={date}&appid={api_key}'
    response = requests.get(url)
    data = response.json()
    return data

def get_current_weather(city):
    url = f'http://api.openweathermap.org/data/2.5/weather?q={city},{twoLetters}&appid={api_key}'
    response = requests.get(url)
    data = response.json()
    return data
while True:
    now = datetime.datetime.now()
    openai.api_key = "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"
    response = openai.ChatCompletion.create(
      model="gpt-3.5-turbo",
      messages=[
        {
          "role": "system",
          "content": "You are system that gets the city or couuntry and has to say it's country's 2 (3 if needed) letter code. For example:\nCall: Kazakhstan\nAnswer: KZ\nCall: Moscow\nAnswer: RU"
        },
        {
          "role": "user",
          "content": "Almaty"
        },
        {
          "role": "assistant",
          "content": "KZ"
        },
        {
          "role": "user",
          "content": "Herat"
        },
        {
          "role": "assistant",
          "content": "AF"
        },
        {
          "role": "user",
          "content": f"{yourCity}"
        }
      ],
      temperature=1,
      max_tokens=3,
      top_p=1,
      frequency_penalty=0,
      presence_penalty=0
    )
    twoLetters = response["choices"][0]["message"]["content"]
    api_key = '16dd18b1f437e8e84069a53e25a8a8e8'
    cities = [f'{yourCity}']
    date = f'{now.strftime("%d-%m-%Y")}'




    for city in cities:
        climate_data = get_climate_data(city)
        current_weather_data = get_current_weather(city)

        if 'main' in current_weather_data and 'weather' in current_weather_data:
            temperature = current_weather_data['main']['temp'] - 273.15
            humidity = current_weather_data['main']['humidity']
            weather_description = current_weather_data['weather'][0]['description']
            wind_speed = current_weather_data['wind']['speed']
            pressure = current_weather_data['main']['pressure']

            print(f'Город: {city}')
            print(f'Дата: {date}')
            print(f'Температура: {temperature:.2f}°C')
            print(f'Скорость ветра: {wind_speed} м/с')
            print(f'Влажность: {humidity}%')
            print(f'Погода: {weather_description}')
            print(f'Атмосферное давление: {pressure * 0.75} mmHg')
            print()


    openai.api_key = "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"
    messages=[
        {
          "role": "system",
          "content": "Imagine that you are a meteorological service specialist who, based on natural data about a city, territory (plain, forest, steppe, etc.) and the microclimate in this city on a certain date, must analyze and derive the probability (in a hundred point system) of a natural disaster (Fires, floods, landslides, earthquakes, tsunamis). Microclimate and territory must be found by itself. "
        },
        {
          "role": "user",
          "content": "City: Almaty\nDate: 02-09-2019\nTemperature: 25.95°C\nWind speed: 3 m/s\nHumidity: 29%\nWeather: scattered clouds\nAtmospheric pressure: 759.75 mmHg"
        },
        {
          "role": "assistant",
          "content": "Fires: 16% chance.\nFloods: 8% chance.\nLandslides: 20% chance.\nEarthquakes: 21% chance.\nTsunami: 1% chance."
        },
        {
          "role": "user",
          "content": "City: Nur-Sultan\nDate: 02-09-2023\nTemperature: 16.97°C\nWind speed: 3 m/s\nHumidity: 63%\nWeather: broken clouds\nAtmospheric pressure: 755.25 mmHg"
        },
        {
          "role": "assistant",
          "content": "Fires: 16% chance.\nFloods: 15% chance.\nLandslides: 10% chance.\nEarthquakes: 17% chance.\nTsunami: 2% chance."
        },
        {
          "role": "user",
          "content": "City: Aktobe\nDate: 02-09-2023\nTemperature: 40.05°C\nWind speed: 90 m/s\nHumidity: 99% \nWeather: rain\nAtmospheric pressure: 1000.0 mmHg\nDon't say anything except the disaster and probability"
        },
        {
          "role": "assistant",
          "content": "Fires: 85% chance.\nFloods: 95% chance.\nLandslides: 40% chance.\nEarthquakes: 43% chance.\nTsunami: 1% chance."
        },
        {
          "role": "user",
          "content": "City: Busan\nDate: 04-09-2022\nTemperature: 29.05°C\nWind speed: 4.2 m/s\nHumidity: 80% \nWeather: rain\nAtmospheric pressure: 757.0 mmHg\nIf you have already answered this question, then repeat the answer."
        },
        {
          "role": "assistant",
          "content": "Fires: 4% chance.\nFloods: 68% chance.\nLandslides: 40% chance.\nEarthquakes: 82% chance.\nTsunami: 76% chance."
        },
        {
          "role": "user",
          "content": f"City: {city}\nDate: {date}\nTemperature: {temperature}°C\nWind speed: {wind_speed} m/s\nHumidity: {humidity}% \nWeather: {weather_description}\nAtmospheric pressure: {pressure * 0.75} mmHg\n"
        }
      ]
    response = openai.ChatCompletion.create(
      model="gpt-3.5-turbo",
      messages=messages,
      temperature=1,
      max_tokens=50,
      top_p=1,
      frequency_penalty=0,
      presence_penalty=0
    )
    print(response["choices"][0]["message"]["content"])
    print()
    time.sleep(120)
